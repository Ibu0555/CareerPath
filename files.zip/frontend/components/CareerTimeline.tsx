"use client";

import { motion } from "framer-motion";

export default function CareerTimeline({
  steps,
}: {
  steps: { role: string; match: string; time: string; gaps: string[] }[];
}) {
  return (
    <div className="relative flex justify-between p-6 bg-white/15 backdrop-blur-md border border-white/20 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.4)]">
      <div className="absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-cyan-500 transform -translate-y-1/2" />
      {steps.map((step, i) => (
        <motion.div
          key={i}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: i * 0.2 }}
          whileHover={{
            scale: 1.05,
            y: -5,
            boxShadow: "0 0 15px rgba(0, 255, 204, 0.5)",
          }}
          className="relative z-10 bg-white/20 border border-white/30 rounded-xl p-4 w-56 text-center backdrop-blur-md"
        >
          <h3 className="font-semibold text-green-400">{step.role}</h3>
          <p className="text-sm text-cyan-300">{step.match} Match</p>
          <p className="text-xs text-gray-400">{step.time}</p>
          {step.gaps.length > 0 && (
            <div className="mt-2">
              <p className="text-xs font-medium text-red-400">Gaps:</p>
              {step.gaps.map((gap) => (
                <motion.div
                  key={gap}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="inline-block bg-red-500/20 border border-red-500/30 rounded-full px-2 py-1 text-xs text-red-300 mr-1"
                >
                  {gap}
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
}