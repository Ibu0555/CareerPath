"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Upload } from "lucide-react";
import axios from "axios";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";

interface Props {
  onSuccess: () => void;
  userId: string;
}

export default function ResumeUpload({ onSuccess, userId }: Props) {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);
    formData.append("user_id", userId);

    try {
      await axios.post(`${process.env.NEXT_PUBLIC_BACKEND_URL || process.env.BACKEND_URL}/upload`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      toast({
        title: "Success",
        description: "Resume uploaded and processed!",
        className: "bg-green-500/20 text-green-400",
      });
      onSuccess();
    } catch (err) {
      toast({
        title: "Error",
        description: "Upload failed",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="p-6 bg-white/15 backdrop-blur-md border border-white/20 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.4)]"
    >
      <h2 className="text-2xl font-semibold mb-4 text-cyan-400">Upload Your Resume</h2>
      <Input
        type="file"
        accept=".pdf,.docx"
        onChange={(e) => setFile(e.target.files?.[0] || null)}
        className="mb-4 bg-white/10 text-white border-white/30"
      />
      <Button
        onClick={handleUpload}
        disabled={!file || uploading}
        className="bg-gradient-to-r from-green-400 to-cyan-500 hover:from-green-500 hover:to-cyan-600 text-white transition-all duration-300 transform hover:-translate-y-1 hover:shadow-[0_0_15px_rgba(0,255,204,0.5)]"
      >
        {uploading ? (
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        ) : (
          <Upload className="mr-2 h-4 w-4" />
        )}
        {uploading ? "Uploading..." : "Upload Now"}
      </Button>
    </motion.div>
  );
}