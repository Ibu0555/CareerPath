"use client";

import { RadarChart, PolarGrid, PolarAngleAxis, Radar } from "recharts";
import { motion } from "framer-motion";

const fallbackData = [
  { skill: "JavaScript", level: 80 },
  { skill: "React", level: 70 },
  { skill: "Python", level: 60 },
];

export default function SkillMap({ skills }: { skills: { skill: string; level: number }[] }) {
  const chartData = skills && skills.length > 0 ? skills : fallbackData;

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="p-6 bg-white/15 backdrop-blur-md border border-white/20 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.4)]"
    >
      <h2 className="text-2xl font-semibold mb-4 text-green-400">Your Skill Galaxy</h2>
      <div className="relative flex justify-center">
        <RadarChart
          outerRadius={120}
          width={400}
          height={300}
          data={chartData}
          className="transform rotate-[-10deg] hover:rotate-0 transition-transform duration-500"
        >
          <PolarGrid stroke="#ffffff20" />
          <PolarAngleAxis dataKey="skill" stroke="#00ffcc" tick={{ fill: "#00ffcc" }} />
          <Radar
            name="Level"
            dataKey="level"
            stroke="#00ffcc"
            fill="#00ffcc"
            fillOpacity={0.3}
            className="drop-shadow-[0_0_10px_rgba(0,255,204,0.7)]"
          />
        </RadarChart>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {chartData.map((s) => (
          <motion.div
            key={s.skill}
            whileHover={{ scale: 1.1, rotate: 5 }}
            className="bg-white/10 border border-white/20 rounded-full px-3 py-1 text-sm text-cyan-400"
          >
            {s.skill}
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}