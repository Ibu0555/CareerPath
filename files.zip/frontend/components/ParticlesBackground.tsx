"use client";

import { Canvas } from "@react-three/fiber";
import { Points, PointMaterial } from "@react-three/drei";
import * as THREE from "three";
import { useEffect, useRef } from "react";

export default function ParticlesBackground() {
  const ref = useRef<THREE.Points>(null!);

  useEffect(() => {
    const positions = new Float32Array(1000 * 3); // 1000 particles
    for (let i = 0; i < 1000; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10;
    }
    if (ref.current) {
      ref.current.geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    }
  }, []);

  return (
    <Canvas style={{ position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh", zIndex: -1 }}>
      <ambientLight intensity={0.5} />
      <Points ref={ref} limit={1000}>
        <PointMaterial color="#00ffcc" size={0.02} transparent opacity={0.7} />
      </Points>
    </Canvas>
  );
}