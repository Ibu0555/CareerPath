"use client";

import { Button } from "@/components/ui/button";
import { Upload } from "lucide-react";
import { signIn, useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";

export default function Home() {
  const { data: session } = useSession();
  const router = useRouter();

  if (session) {
    router.push("/dashboard");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-blue-900 flex flex-col justify-center items-center text-white p-4 relative overflow-hidden">
      <motion.h1
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1 }}
        className="text-5xl md:text-7xl font-extrabold mb-6 text-center text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-cyan-400 drop-shadow-lg"
      >
        AI Career Revolution
      </motion.h1>
      <motion.p
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, delay: 0.2 }}
        className="text-xl md:text-2xl mb-10 text-center max-w-lg text-gray-200 drop-shadow-md"
      >
        Unlock personalized skill maps, career paths, and job recs with cutting-edge AI.
      </motion.p>
      <motion.div
        whileHover={{ scale: 1.1, rotateZ: 5 }}
        whileTap={{ scale: 0.95 }}
        className="backdrop-blur-md bg-white/20 border border-white/30 rounded-xl p-6 shadow-[0_8px_30px_rgba(0,0,0,0.3)]"
      >
        <Button
          onClick={() => signIn("google")}
          size="lg"
          className="bg-gradient-to-r from-green-400 to-cyan-500 text-white hover:from-green-500 hover:to-cyan-600 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg"
        >
          <Upload className="mr-2 h-6 w-6" />
          Sign in with Google
        </Button>
      </motion.div>
    </div>
  );
}