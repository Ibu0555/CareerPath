"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import SkillMap from "@/components/SkillMap";
import CareerTimeline from "@/components/CareerTimeline";
import ResumeUpload from "@/components/ResumeUpload";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import axios from "axios";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [skills, setSkills] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    if (status === "unauthenticated") router.push("/");
    if (session) fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, status, router]);

  const fetchData = async () => {
    try {
      const res = await axios.get(
        `${process.env.NEXT_PUBLIC_BACKEND_URL || process.env.BACKEND_URL}/recommend/${session?.user.id}`
      );
      setSkills(res.data.skills || []);
      setRecommendations(res.data.recommendations || []);
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to load data",
        variant: "destructive",
      });
    }
  };

  const handleUploadSuccess = () => fetchData();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900 p-6 text-white">
      <header className="mb-8">
        <motion.h1
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-cyan-400"
        >
          Welcome, {session?.user.name}
        </motion.h1>
      </header>
      <Tabs defaultValue="upload" className="w-full">
        <TabsList className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-1">
          <TabsTrigger value="upload" className="data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400">
            Upload Resume
          </TabsTrigger>
          <TabsTrigger value="skills" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            Skill Map
          </TabsTrigger>
          <TabsTrigger value="career" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
            Career Path
          </TabsTrigger>
        </TabsList>
        <TabsContent value="upload">
          <Card className="bg-white/10 backdrop-blur-md border border-white/20">
            <CardContent className="p-6">
              <ResumeUpload onSuccess={handleUploadSuccess} userId={session?.user.id} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="skills">
          <Card className="bg-white/10 backdrop-blur-md border border-white/20">
            <CardHeader>
              <CardTitle className="text-green-400">Your Skills</CardTitle>
            </CardHeader>
            <CardContent>
              <SkillMap skills={skills} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="career">
          <Card className="bg-white/10 backdrop-blur-md border border-white/20">
            <CardHeader>
              <CardTitle className="text-cyan-400">Career Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <CareerTimeline steps={recommendations} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}