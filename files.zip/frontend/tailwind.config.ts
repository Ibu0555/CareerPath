/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'custom-green': '#00ffcc',
        'custom-cyan': '#00ffff',
        'custom-purple': '#a100ff',
      },
      boxShadow: {
        'neon': '0 0 15px rgba(0, 255, 204, 0.7)',
      },
    },
  },
  plugins: [],
};