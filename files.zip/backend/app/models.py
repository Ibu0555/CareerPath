from pydantic import BaseModel
from typing import List

class Skill(BaseModel):
    skill: str
    level: int

class SkillResponse(BaseModel):
    skills: List[Skill]

class Step(BaseModel):
    role: str
    match: str
    time: str
    gaps: List[str]

class RecommendationResponse(BaseModel):
    recommendations: List[Step]
    advice: str = ""