import os
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI
from dotenv import load_dotenv
import psycopg2
from psycopg2.extras import execute_values
from app.utils import extract_text, get_embedding
from app.models import SkillResponse, RecommendationResponse
from pydantic import BaseModel
import numpy as np

load_dotenv()

app = FastAPI()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# DB Connection Pool
conn = psycopg2.connect(os.getenv("DATABASE_URL"), options="-c search_path=public")
conn.autocommit = True  # For simplicity; use transactions in prod

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

class UploadBody(BaseModel):
    user_id: str

@app.post("/upload", response_model=SkillResponse)
async def upload_resume(file: UploadFile = File(...), user_id: str = Form(...)):
    try:
        text = extract_text(file)
        if not text:
            raise HTTPException(400, "Invalid file or empty content")

        # AI Extract Skills
        completion = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Extract unique skills from resume as JSON: {'skills': ['skill1', 'skill2']}."},
                {"role": "user", "content": text}
            ]
        )
        skills_json = eval(completion.choices[0].message.content.strip())  # Use json.loads for prod!
        skills = skills_json.get('skills', [])

        # Store Embeddings
        embeddings = [get_embedding(skill) for skill in skills]
        data = [(user_id, skill, emb) for skill, emb in zip(skills, embeddings)]
        with conn.cursor() as cur:
            execute_values(cur, "INSERT INTO skills (user_id, skill, embedding) VALUES %s ON CONFLICT DO NOTHING", data)

        return {"skills": [{"skill": s, "level": 50} for s in skills]}  # Dummy levels; compute real via AI
    except Exception as e:
        raise HTTPException(500, f"Server error: {str(e)}")

@app.get("/recommend/{user_id}", response_model=RecommendationResponse)
async def get_recommendations(user_id: str):
    try:
        # Sample job paths (embed in DB for prod)
        job_paths = [
            {"role": "Frontend Developer", "req_skills": ["JavaScript", "React", "CSS"], "embedding": get_embedding("JavaScript React CSS")},
            {"role": "Senior React Developer", "req_skills": ["React", "TypeScript", "AWS"], "embedding": get_embedding("React TypeScript AWS")},
            {"role": "Frontend Architect", "req_skills": ["Architecture", "Leadership", "DevOps"], "embedding": get_embedding("Architecture Leadership DevOps")}
        ]

        with conn.cursor() as cur:
            # Fetch user skills
            cur.execute("SELECT skill, embedding FROM skills WHERE user_id = %s", (user_id,))
            user_skills = cur.fetchall()

        if not user_skills:
            return {"recommendations": []}

        # Compute matches
        steps = []
        for job in job_paths:
            distances = []
            for _, user_emb in user_skills:
                dist = np.linalg.norm(np.array(job["embedding"]) - np.array(user_emb))  # Cosine approx
                distances.append(dist)
            avg_match = 100 - (sum(distances) / len(distances) * 100) if distances else 0  # Simplify
            gaps = [s for s in job["req_skills"] if s not in [sk[0] for sk in user_skills]]
            steps.append({
                "role": job["role"],
                "match": f"{int(avg_match)}%",
                "time": "+1-2 years" if avg_match > 50 else "+3-4 years",
                "gaps": gaps
            })

        # AI Enhance Recs
        prompt = f"User skills: {[sk[0] for sk in user_skills]}. Generate personalized career advice."
        completion = client.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": prompt}])
        advice = completion.choices[0].message.content

        return {"recommendations": steps, "advice": advice}
    except Exception as e:
        raise HTTPException(500, f"Server error: {str(e)}")