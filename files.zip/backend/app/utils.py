import pdfplumber
from docx import Document
from openai import OpenAI
import os
from fastapi import UploadFile

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def extract_text(file: UploadFile):
    content = file.file.read()
    if file.filename.endswith('.pdf'):
        with pdfplumber.open(file.file) as pdf:
            return ' '.join(page.extract_text() or '' for page in pdf.pages)
    elif file.filename.endswith('.docx'):
        doc = Document(file.file)
        return ' '.join(para.text for para in doc.paragraphs)
    return ""

def get_embedding(text: str):
    response = client.embeddings.create(input=text, model="text-embedding-3-small")
    return response.data[0].embedding