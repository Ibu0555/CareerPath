from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_upload_resume():
    response = client.post("/upload", files={"file": ("test.pdf", b"dummy content")}, data={"user_id": "1"})
    assert response.status_code == 200
    assert "skills" in response.json()