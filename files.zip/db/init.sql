CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS skills (
    id SERIAL PRIMARY KEY,
    user_id TEXT NOT NULL,
    skill TEXT NOT NULL,
    embedding VECTOR(1536),
    UNIQUE(user_id, skill)
);

-- Index for vector search
CREATE INDEX IF NOT EXISTS skills_embedding_idx ON skills USING hnsw (embedding vector_cosine_ops);